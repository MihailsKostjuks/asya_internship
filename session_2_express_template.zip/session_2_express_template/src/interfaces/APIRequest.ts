export interface ApiRequest {
    // task: string,
    payload: number
}
